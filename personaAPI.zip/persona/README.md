# API persona con spring
 Una api creada con spring jpa lombok 
